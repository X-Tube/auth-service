package com.microservice.authservice.service;

import com.microservice.authservice.dto.LoginRequestDTO;
import com.microservice.authservice.dto.LoginResponseDTO;
import com.microservice.authservice.dto.RegisterRequestDTO;
import com.microservice.authservice.dto.TokenPairResponse;
import com.microservice.authservice.model.User;
import com.microservice.authservice.repository.UserRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class AuthService {

    private final JwtService jwtService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;

    public String register(RegisterRequestDTO dto) {

        if(userRepository.findByEmail(dto.email()).isPresent()){
            throw new RuntimeException("Email already registered");
        }

        User user = new User();
        user.setEmail(dto.email());
        user.setPassword(passwordEncoder.encode(dto.password()));

        userRepository.save(user);

        return "New user successfully registered!";
    }

    public TokenPairResponse login(LoginRequestDTO dto) {
            var unauthenticatedToken = new UsernamePasswordAuthenticationToken(dto.email(), dto.password());
            Authentication authentication = authenticationManager.authenticate(unauthenticatedToken);

        User user = (User) authentication.getPrincipal();

        String accessToken = jwtService.generateToken(user);
        String refreshToken = createRefreshToken(user);
        return new TokenPairResponse(accessToken, refreshToken);
    }


}
